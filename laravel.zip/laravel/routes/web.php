<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('index1',"order\OrderController@index");
Route::post('msg',"order\OrderController@msg");
Route::get('show1/{id}',function($id){
//    echo $id;
    if($id >2){
        return redirect('http://www.baidu.com');
    }else{
        echo redirect('http://www.4399.com');
    }
});
Route::prefix('admin')->group(function () {
    Route::get('index', function () {
        echo '安玉鹏';
    });
});
Route::any('some',"order\OrderController@some");
Route::any('show',"order\OrderController@show");
Route::any('dele',"order\OrderController@dele");
Route::any('updat',"order\OrderController@updat");
Route::any('updatedata',"order\OrderController@updatedata");
Route::any('update2',"order\OrderController@update2");
Route::any('seach',"order\OrderController@seach");
Route::any('ajaxupd',"order\OrderController@ajaxupd");
Route::any('index',"IndexController@index");
Route::any('register',"IndexController@register");
Route::any('userpage',"IndexController@userpage")->Middleware('userpage');
Route::any('set',"IndexController@set");
Route::any('login',"IndexController@login");
Route::any('zhuce',"IndexController@zhuce");
Route::any('denglu',"IndexController@denglu");
Route::any('t1',"IndexController@t1");
ROUTE::any('t2',"IndexController@t2");
Route::any('allshops',"IndexController@allshops");
Route::any('newshow',"IndexController@newshow");
Route::any('shopcart',"IndexController@shopcart");
Route::post('addli',"IndexController@addli");
Route::any('selegood',"IndexController@selegood");
Route::any('xiangqing',"IndexController@xiangqing");
Route::any('zhoume',"IndexController@zhoume");
Route::any('car',"IndexController@car");
Route::any('jiashan',"IndexController@jiashan");
Route::any('payment',"IndexController@payment");
Route::any('pishan',"IndexController@pishan");
Route::any('jia',"IndexController@jia");
Route::any('jian',"IndexController@jian");
Route::any('kuang',"IndexController@kuang");
Route::any('pay',"IndexController@pay");
Route::any('address',"IndexController@address");
Route::any('success',"IndexController@success");
Route::any('moren',"IndexController@moren");
Route::any('writeaddr',"IndexController@writeaddr");
Route::any('dizhi',"IndexController@dizhi");
Route::any('paysuccess',"IndexController@paysuccess");
Route::any('dzdel',"IndexController@dzdel");
Route::any('writeaddrs',"IndexController@writeaddrs");
Route::any('dizhixiu',"IndexController@dizhixiu");
Route::any('buyrecord',"IndexController@buyrecord");







