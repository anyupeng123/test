@foreach($info as $k=>$v)
<li id="23468">    

                                    <span class="gList_l fl">        
                                        <img class="lazy" src="/uploads/{{$v->goods_img}}">
                                    </span>    
                                    <div class="gList_r">        
                                        <a href="/xiangqing?goods_id={{$v->goods_id}}"> <h3 class="gray6" value="{{$v->goods_id}}">(第17094云){{$v->goods_name}}（Apple）iPhone 7 Plus 256G版 4G手机</h3>   </a>      
                                        <em class="gray9">价值：￥{{$v->shop_price}}</em>
                                        <div class="gRate">            
                                            <div class="Progress-bar">    
                                                <p class="u-progress">
                                                    <span style="width:60%;" class="pgbar">
                                                        <span class="pging"></span>
                                                    </span>
                                                </p>                
                                                <ul class="Pro-bar-li">
                                                    <li class="P-bar01"><em>7342</em>已参与</li>
                                                    <li class="P-bar02"><em>7988</em>总需人次</li>
                                                    <li class="P-bar03"><em>646</em>剩余</li>
                                                </ul>            
                                            </div>           
                                            <a codeid="12785750" class="" canbuy="646"><s></s></a>        
                                        </div>    
                                    </div>
                                   
                                </li>
                                @endforeach