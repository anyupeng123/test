<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="/js/jquery.js"></script>
</head>
<body>
    <form action="" method="" id="form">
    <center>
    <table >
    <tr>
        <td>名称</td>
        <td><input type="text" name="name"></td>
    </tr>
    <tr>
        <td>分类</td>
        <td><select name="fenlei" id="">
            <option value="生活用品">生活用品</option>
            <option value="情趣用品">情趣用品</option>
            <option value="数码电器">数码电器</option>
            <option value="美妆用品">美妆用品</option>
            <option value="家居用品">家居用品</option>
        </select></td>
    </tr>
    <tr>
        <td>描述</td>
        <td><textarea name="miaoshu" id="" cols="30" rows="10"></textarea></td>
    </tr>
    <tr>
        <td>是否热销</td>
        <td>是<input type="radio" name="rexiao" value="1" checked>
            否<input type="radio" name="rexiao" value="0">
        </td>
    </tr>
    <tr>
        <td>是否上架</td>
        <td>是<input type="radio" name="shangjia" value="1" checked>
            否<input type="radio" name="shangjia" value="0"></td>
    </tr>
    <tr>
       <td><input type="button" id="btn" value="确定"></td> 
    </tr>
    </table>
    </center>
    </form>
</body>
</html>
<script>
$(function(){
$('#btn').click(function(){
    var data=$('#form').serialize();
    $.ajax({
    method: "POST",
    url: "some",
    data: data
    }).done(function( msg ) {
        //alert(msg);
    if(msg.code==1){
        alert(msg.msg);
        window.location.href="show";
    }
    });

})
})
</script>