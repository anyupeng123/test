<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Car extends Model
{
   protected $table='car';
   public $timestamps = false;
}
