<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="/js/jquery.js"></script>
</head>
<div id="th">
<style>
    table{border:1px solid #666;border-collapse: collapse;width:900px;margin:10px auto;font-size: 14px;color:#666;}
    th,td{border:1px solid #666;height:25px;text-align:center;}
    a{border:1px solid #666;text-decoration: none;padding: 0 5px;border-radius: 5px;color:#666;}
    a:hover,a.current{border:1px solid plum;color:plum;}
    ul li{
        text-decoration: none;
        padding: 0 5px;
        border-radius: 5px;
        color:orange;
        list-style:none;
        float:left;
        font-size:20px;
        margin-left:10px;
     }
    ul li a{
        text-decoration: none;
    }
    ul{
        margin-left:400px;
     }
</style>
<body>
<form action="">
<center>
<table>
    <select name="rexiao" id="">
        <option value="">请选择是否热销</option>
        <option value="1">是</option>
        <option value="0">否</option>
    </select>
    <select name="shangjia" id="">
        <option value="">请选择是否上架</option>
        <option value="1">是</option>
        <option value="0">否</option>
    </select>
    <input type="button" value="搜索" id="seach">
</table>
</center>
</form>
    <table border>
        <tr>
        <td>ID</td>
            <td>名称</td>
            <td>分类</td>
            <td>描述</td>
            <td>是否热销</td>
            <td>是否上架</td>
            <td>操作</td>
        </tr>
         <?php $__currentLoopData = $bol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <tr>
            <td><?php echo e($v->id); ?></td>
            <td id='<?php echo e($v->id); ?>'><span class="name"><?php echo e($v->name); ?></span></td>
            <td><?php echo e($v->fenlei); ?></td>
            <td><?php echo e($v->miaoshu); ?></td>
            <td id="<?php echo e($v->id); ?>"><?php if ($v->rexiao ==1) { ?>
            <input type="submit" value="是" id="upd" > 
            <?php }else{?>
                <input type="submit" value="否" id="upd">
            <?php }?>
            </td>
            <td><?php if ($v->shangjia ==1) { ?>
            <input type="submit" value="是" id="upd">
            <?php }else{?>
                <input type="submit" value="否" id="upd">
            <?php }?></td>
            <td><a href="updatedata?id=<?php echo e($v->id); ?>" >修改</a>
                <a  href="javascript:;" onclick="dele(<?php echo e($v->id); ?>)">删除</a>
            </td>
            
        </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php echo e($bol->links()); ?>

</body>
</div>
</html>
<script>
function dele(id){
    $.ajax({
    method: "POST",
    url: "dele",
    data: {id:id}
    }).done(function( msg ) {
        if(msg.code==1){
        alert(msg.msg);
        window.location.href="show";
    }
    });
}
function upda(id){
    $.ajax({
    method: "POST",
    url: "updatedata",
    data: {id:id}
    }).done(function( msg ) {
        //console.log(msg);
        window.location.href="updatedata";
    }); 
}
$(document).on('click','#upd',function(){
    var _this=$(this);
    var nam=$(this).val();
    var id=$(this).parent().attr('id');
    if(nam=='是'){
        $(this).val('否');
        na=0;
    }else{
        $(this).val('是');
        na=1;
    }
    //ajax传输
    $.ajax({
    method: "POST",
    url: "updat",
    data: {id:id,na:na}
    }).done(function( msg ) {
        //alert(msg);
    });
})
$('#seach').click(function(){
    var rexiao=$("select[name='rexiao']").val();
    var shangjia=$("select[name='shangjia']").val();
    $.ajax({
    method: "POST",
    url: "seach",
    data: {rexiao:rexiao,shangjia:shangjia}
    }).done(function( msg ) {
        //alert(msg);
        if(msg==2){
            alert('请选择搜索的商品');
        }else{
            $('#th').html(msg);
        }
    });
})
$(document).on('click','.name',function(){
    var _this=$(this);
    //alert(_this);
    var mobile=_this.text();
    _this.parent().html('<input type="text" class="ajaxupd" value='+mobile+'>');
})
$(document).on('blur','.ajaxupd',function(){
    var _this=$(this);
    var mobile=_this.val();
    var id =_this.parent().attr('id');
    // alert(id);
    $.ajax({
    method: "POST",
    url: "ajaxupd",
    data: {mobile:mobile,id:id}
    }).done(function( msg ) {
       // alert(msg);
       if(msg==1){
        _this.parent().html("<span class='modile'>"+mobile+"</span>");
       }
    });
})
</script>