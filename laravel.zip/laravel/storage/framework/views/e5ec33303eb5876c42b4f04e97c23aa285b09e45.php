<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="/js/jquery.js"></script>
</head>
<body>
    <form action="" method="" id="form">
    <center>
    <table >
    <input type="hidden" name="id" value="<?php echo e($data['id']); ?>">
    <tr>
    
        <td>名称</td>
        <td><input type="text" name="name" value="<?php echo e($data['name']); ?>"></td>
    </tr>
    <tr>
        <td>分类</td>
        <td><select name="fenlei" id="">
            <option value="生活用品">生活用品</option>
            <option value="美妆用品">美妆用品</option>
            <option value="家居用品">家居用品</option>
        </select></td>
    </tr>
    <tr>
        <td>描述</td>
        <td><textarea name="miaoshu" id="" cols="30" rows="10"><?php echo e($data['miaoshu']); ?></textarea></td>
    </tr>
    <tr>
        <td>是否热销</td>
        <td><?php if ($data['rexiao']==1) {?>
        是<input type="radio" name="rexiao" value="1" checked>
            否<input type="radio" name="rexiao" value="0">
        <?php }else{?>
            是<input type="radio" name="rexiao" value="1" >
            否<input type="radio" name="rexiao" value="0" checked>
        <?php }?>
        </td>
    </tr>
    <tr>
        <td>是否上架</td>
        <td>
        <?php if ($data['shangjia']==1) {?>
            是<input type="radio" name="shangjia" value="1" checked>
            否<input type="radio" name="shangjia" value="0" > 
            <?php }else{?>  
            是<input type="radio" name="shangjia" value="1" >
            否<input type="radio" name="shangjia" value="0" checked> 
                <?php }?>
            </td>
    </tr>
    <tr>
       <td><input type="button" id="btn" value="修改"></td> 
    </tr>
    </table>
    </center>
    </form>
</body>
</html>
<script>
$('#btn').click(function(){
    var data=$('#form').serialize();
    //console.log(data);
   // var data={};
    var url = "update2";
    $.ajax({
        type: "POST",
        url: url,
        data: data,
        dataType:"json",
        success:function(msg){
            if(msg.code==1){
                alert(msg.msg);
            }else{
                alert('修改失败');
            }
        }
    });

})
</script>